<?php 


$host= "localhost";
$port="5433";
$db="users";
$user= "postgres";
$password="postgres";



$db = pg_connect("host=".$host." port=".$port." dbname=".$db." user=".$user." password=".$password);

if(!$db) {

      echo "Error : Unable to open database\n";
   } 





?>