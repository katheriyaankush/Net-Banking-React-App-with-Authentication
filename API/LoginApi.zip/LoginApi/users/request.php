<?php 

ini_set('display_errors', '0');
$request_method=$_SERVER["REQUEST_METHOD"];
$entityBody = file_get_contents('php://input');


$allData = json_decode($entityBody);

$user_name = $allData->email;
$name = $allData->name;
$password = $allData->password;
$PassLength =strlen($password);
$password =   base64_encode($password) ;




?>