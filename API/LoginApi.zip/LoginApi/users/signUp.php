<?php 


include_once '../config/config.php';
include_once './request.php';


$token = "tokenuser".date("YmdHis").rand(11111,99999);
$cData=date("Y-m-d h:m:s");


 $query =  " INSERT INTO users (name, username, password,token_id, created) VALUES ( '".$name."','".$user_name."', '".$password."','".$token."', '".$cData."')";



if($PassLength>=6){
$result=pg_query($query);


if ($result)
    {
        $data["message"] = "Successfully Registered ";
        $data["status"] = "Ok";
        $data["expiresIn"]="36000";    }
    else
    {
    $data ='{  "error": {    "code": 400,     "message": "Already Exist" }}';
        $data = json_decode($data);
    }

}


else{

$data ='{  "error": {    "code": 400,     "message": "Password to short" }}';
$data = json_decode($data);

}


   echo json_encode($data);



?>