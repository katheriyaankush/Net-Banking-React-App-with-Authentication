<?php 

include_once '../config/config.php';
include_once './request.php';




$query = "select token_id as idToken , name from users where username= '".$user_name."' and password='".$password."'";

$result=pg_query($query);

$data = pg_fetch_assoc($result);

if($data)
{

$data += ['expiresIn'=> '3600' ,'localId'=>'23456789042343435fvfd' , 'message'=>'successfully login'];
}
else {

$data ='{  "error": {    "code": 400,     "message": "Email and Password Wrong" }}';
$data = json_decode($data);


}

   echo json_encode($data);


?>